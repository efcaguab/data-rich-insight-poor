#
# This is the server logic of a Shiny web application. You can run the 
# application by clicking 'Run App' above.
#
# Find out more about building applications with Shiny here:
# 
#    http://shiny.rstudio.com/
#

library(shiny)
library(dplyr)
library(foreach)

ext_top_data <- function(d, field) {
  d <- lapply(d, function(x) x[[field]])
  d <- unlist(d)
  d <- trimws(d)
  tolower(d)
}

community_df <- function(x){
  x <- x[, c("group_kl9eo56", "Site")]
  xx <- list(0, 0)
  foreach (i =  1:nrow(x), .combine = rbind) %do% {
    data.frame(sp = unlist(x[i, 1]), site = unlist(x[i, 2]))
  }
}

community_tb <- function(x){
  xx <- community_df(x)
  xx <- reshape2::acast(xx, site ~ sp)
  is.na(xx)
}

# Define server logic required to draw a histogram
shinyServer(function(input, output, session) {
  
  data <- reactivePoll(1000, session,
    checkFunc = function(){
      form_metadata <- httr::GET("https://kc.kobotoolbox.org/api/v1/forms/111907",
                                 httr::authenticate("efcaguab", "DQe1csPKT14!"))
      form_metadata <- httr::content(form_metadata)
      form_metadata$date_modified
    },
    valueFunc = function(){
      d <- httr::GET("https://kc.kobotoolbox.org/api/v1/data/111907", 
                     httr::authenticate("efcaguab", "DQe1csPKT14!")) 
      d <- httr::content(d)
      d <- jsonlite::toJSON(d)
      jsonlite::fromJSON(d)
    }
  )
  

  output$spp_acc_curve <- renderTable({
    community_df(data()) %>%
      group_by(sp) %>%
      summarise(frequency = n_distinct(site)) %>%
      arrange(desc(frequency))
  })
   
  output$distPlot <- renderPlot({
    
    speac <- vegan::specaccum(community_tb(data()), "random")
    plot(speac, ci.type="poly", col="blue", lwd=2, ci.lty=0, ci.col="lightblue")
    # boxplot(speac, col="yellow", add=TRUE, pch="+")
    
  })
  
})
